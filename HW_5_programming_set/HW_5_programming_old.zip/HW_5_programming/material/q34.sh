python3 dnn_mlp.py --dropout_rate 0.5
