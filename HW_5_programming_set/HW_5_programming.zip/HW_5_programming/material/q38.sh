python3 dnn_cnn.py --alpha 0.9
