py -3 dnn_cnn.py
