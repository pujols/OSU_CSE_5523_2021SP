py -3 dnn_mlp.py
